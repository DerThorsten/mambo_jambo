pdflatex seminar.tex
makeindex seminar.nlo -s nomencl.ist -o seminar.nls
pdflatex seminar.tex

pdflatex seminar.tex
makeindex seminar.nlo -s nomencl.ist -o seminar.nls
pdflatex seminar.tex

pdflatex seminar.tex
makeindex seminar.nlo -s nomencl.ist -o seminar.nls
pdflatex seminar.tex
