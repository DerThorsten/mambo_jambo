for i in *.svg; do
    echo $i
    inkscape --export-pdf=`basename $i .svg`.pdf $i
done;
